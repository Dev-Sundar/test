package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cricketclub.utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AddProductsServlet")
public class AddProductsServlet extends HttpServlet{
	public static final long serialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest request,HttpServletResponse response)
		throws ServletException ,IOException {
		response.getWriter().println("get method is not supported");
		
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Retrieve form data
        String productId = request.getParameter("productId");
        String productName = request.getParameter("productName");
        double productPrice =  Double.parseDouble(request.getParameter("productPrice"));
        String productStocks = request.getParameter("productStocks");
        
        response.setContentType("text/html");
        //response.getWriter().println("<h3>Product Added Successfully!</h3>");

	
	// Example: Save product data to a database
        try {
			Connection conn = com.shopping_web.utils.DBConnection.getConnection();
			String sql = "INSERT INTO products(id,name,price,total_stocks) VALUES(?,?,?,?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, productId);
			stmt.setString(2, productName);
			stmt.setDouble(3, productPrice);
			stmt.setString(4, productStocks);
			
			int rowInserted = stmt.executeUpdate();
			conn.close();
			
			if (rowInserted > 0) {
				response.getWriter().println("<h4>Product added Successfully</h4>");			
		} else {
			response.getWriter().println("Product  not added Successfully");
		}
	}	catch(SQLException e) {
		e.printStackTrace();
		response.getWriter().println("Database Error :"+e.getMessage());
	}
		
		
	}

}
