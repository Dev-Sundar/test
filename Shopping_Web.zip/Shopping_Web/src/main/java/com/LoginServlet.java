package com;

import java.io.IOException;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.shopping_web.utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException,IOException{
		response.getWriter().println("Not Supported")
		
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException,IOException{
		String UserName = request.getParameter("UserName");
		String password = request.getParameter("password");
		
		boolean isValidUser = false;
		
		try {
			Connection conn = DBConnection.getConnection();
			String sql = "SELECT FROM customer WHERE UserName = ? AND password = ?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1,UserName);
			stmt.setString(2,password);
			
			
			ResultSet rs = stmt.executeQuery();
			isValidUser = rs.next();
			
			rs.close();
			stmt.close();
			conn.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		if (isValidUser) {
            response.getWriter().println("Login successful! Welcome, " + UserName + "!");
        } else {
            response.getWriter().println("Invalid username or password. Please try again.");
        }
		
	}

}
