package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import com.shopping_web.utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/AddtoCartServlet")
public class AddtoCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        int productId = Integer.parseInt(request.getParameter("productId"));
        double productPrice = 0;
        

        HttpSession session = request.getSession();
        ArrayList<Integer> cart = (ArrayList<Integer>) session.getAttribute("cart");

        if (cart == null) {
            cart = new ArrayList<>();
        }

        cart.add(productId);
        session.setAttribute("cart", cart);

        response.getWriter().println("Product added to cart successfully!");
        
    
    try {
    	Connection conn = DBConnection.getConnection();
    	String sql = "INSERT INTO cart(product_name,price)VALUES(?,?)";
    	PreparedStatement stmt = conn.prepareStatement(sql);
    	stmt.setString(1, "productName");
    	stmt.setDouble(2, productPrice);
    	//stmt.setString(3, "quantity");
    	int rowInserted = stmt.executeUpdate();
		conn.close();
    
		
		if (rowInserted > 0) {
			response.getWriter().println("<h4>Product added Successfully</h4>");			
	} else {
		response.getWriter().println("Product  not added Successfully");
	}
}	catch(SQLException e) {
	e.printStackTrace();
	response.getWriter().println("Database Error :"+e.getMessage());
}
    }
}
