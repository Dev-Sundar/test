package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.shopping_web.utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ProductListServlet")
public class ProductListServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        try {
            // Get the database connection
            Connection conn = DBConnection.getConnection();

            // SQL query to fetch product data
            String sql = "SELECT * FROM products";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            // Generate styled HTML response
            out.println("<html><head><title>Product List</title>");
            out.println("<style>");
            out.println("body { font-family: Arial, sans-serif; background-color: #f4f4f9; margin: 20px; }");
            out.println("h1 { color: #333; text-align: center; }");
            out.println("table { width: 80%; margin: 0 auto; border-collapse: collapse; background-color: #fff; }");
            out.println("th, td { padding: 12px; text-align: center; border: 1px solid #ddd; }");
            out.println("th { background-color: #007bff; color: white; }");
            out.println("tr:nth-child(even) { background-color: #f2f2f2; }");
            out.println("button { background-color: #28a745; color: white; border: none; padding: 8px 12px; cursor: pointer; border-radius: 5px; }");
            out.println("button:hover { background-color: #218838; }");
            out.println("</style>");
            out.println("</head><body>");
            
            out.println("<h1>Available Products</h1>");
            out.println("<table>");
            out.println("<tr><th>Product Name</th><th>Price</th><th>Stock</th><th>Action</th></tr>");

            while (rs.next()) {
                int id = rs.getInt("product_id");
                String name = rs.getString("product_name");
                double price = rs.getDouble("price");
                int totalStocks = rs.getInt("total_stocks");

                out.println("<tr>");
                out.println("<td>" + name + "</td>");
                out.println("<td>$" + price + "</td>");
                out.println("<td>" + totalStocks + "</td>");
                out.println("<td>");
                out.println("<form action='AddtoCartServlet' method='post'>");
                out.println("<input type='hidden' name='productId' value='" + id + "'>");
                out.println("<button type='submit'>Add to Cart</button>");
                out.println("</form>");
                out.println("</td>");
                out.println("</tr>");
            }

            out.println("</table>");
            out.println("</body></html>");

            // Clean up resources
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<p style='color: red; text-align: center;'>Error fetching products. Please try again later.</p>");
        }
    }
}
