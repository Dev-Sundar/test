package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.shopping_web.utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.getWriter().println("Not Supported");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userName = request.getParameter("username");
        String password = request.getParameter("password");

        boolean isValidUser = false;

        try {
            // Establish database connection
            Connection conn = DBConnection.getConnection();

            // Corrected SQL query to select all columns from the customer table
            String sql = "SELECT * FROM customer WHERE UserName = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, userName);
            stmt.setString(2, password); // Ideally, hash the password before comparing
            
            // Execute query
            ResultSet rs = stmt.executeQuery();
            isValidUser = rs.next(); // If a record exists, login is successful
            response.getWriter().println(rs.getString(1));
            // Clean up resources
            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Check if the user exists and respond accordingly
        if (isValidUser) {
            response.getWriter().println("Login successful! Welcome, " + userName + "!");
        } else {
            response.getWriter().println("Invalid username or password. Please try again.");
        }
    }
}
