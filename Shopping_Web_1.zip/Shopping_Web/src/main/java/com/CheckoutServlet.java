package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.shopping_web.utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/CheckoutServlet")
public class CheckoutServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.getWriter().println("Method not supported.");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Initialize response and total price
        response.setContentType("text/html");
        StringBuilder output = new StringBuilder();
        double totalPrice = 0.0;

        // Define SQL query to fetch cart items
        String selectQuery = "SELECT product_id, product_name, price FROM cart";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(selectQuery);
             ResultSet resultSet = statement.executeQuery()) {

            // Generate HTML content
            output.append("<html><head><title>Checkout</title>")
                  .append("<style>")
                  .append("body { font-family: Arial, sans-serif; margin: 20px; background-color: #f4f4f9; }")
                  .append("h1 { color: #333; text-align: center; }")
                  .append("table { width: 80%; margin: 20px auto; border-collapse: collapse; background: #fff; }")
                  .append("th, td { padding: 12px; border: 1px solid #ddd; text-align: center; }")
                  .append("th { background-color: #007bff; color: white; }")
                  .append("tr:nth-child(even) { background-color: #f2f2f2; }")
                  .append(".total { font-weight: bold; color: #333; text-align: right; margin-top: 10px; }")
                  .append("button { background-color: #28a745; color: white; border: none; padding: 10px 15px; cursor: pointer; border-radius: 5px; }")
                  .append("button:hover { background-color: #218838; }")
                  .append("</style></head><body>");

            output.append("<h1>Your Cart</h1>");
            output.append("<table>");
            output.append("<tr><th>Product ID</th><th>Product Name</th><th>Price</th></tr>");

            // Loop through the result set
            while (resultSet.next()) {
                String productId = resultSet.getString("product_id");
                String productName = resultSet.getString("product_name");
                double price = resultSet.getDouble("price");
                totalPrice += price;

                output.append("<tr>")
                      .append("<td>").append(productId).append("</td>")
                      .append("<td>").append(productName).append("</td>")
                      .append("<td>$").append(String.format("%.2f", price)).append("</td>")
                      .append("</tr>");
            }

            output.append("</table>");

            // Display the total price
            output.append("<div class='total'>")
                  .append("Total Price: $").append(String.format("%.2f", totalPrice))
                  .append("</div>");

            // Checkout button
            output.append("<form action='cart.html' method='POST' style='text-align: center; margin-top: 20px;'>")
                  .append("<button type='submit'>Proceed to Checkout</button>")
                  .append("</form>");

            output.append("</body></html>");

            response.getWriter().println(output.toString());

        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("<p style='color: red;'>Database error occurred: " + e.getMessage() + "</p>");
        }
    }
}
