package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.shopping_web.utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@Override
	protected void doGet(HttpServletRequest request,HttpServletResponse response)
		throws ServletException,IOException{
		response.getWriter().println("Method not Supported");
	}
	
	@Override
	protected void doPost(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{
		
		String UserName = request.getParameter("UserName");
		String email = request.getParameter("email");
		String mobile_number = request.getParameter("mobile_number");
		String password = request.getParameter("password");
	
	
	try {
		Connection conn = DBConnection.getConnection();
		String sql = "INSERT INTO customer(UserName,email,mobile_number,password) VALUES(?,?,?,?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setString(1,UserName);
		stmt.setString(2,email);
		stmt.setString(3,mobile_number);
		stmt.setString(4,password);
		int rowInserted = stmt.executeUpdate();
		conn.close();
		
		if (rowInserted > 0) {
			response.getWriter().println("<h4>User Register Successfully</h4>");			
	} else {
		response.getWriter().println("User Not registered");
	}
}	catch(SQLException e) {
	e.printStackTrace();
	response.getWriter().println("Database Error :"+e.getMessage());
}
	}
	
	

	}

