package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.shopping_web.utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/CheckoutServlet")
public class CheckoutServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    

    @Override
    public void init() throws ServletException {
      
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.getWriter().println("Method not Supported");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Initialize the response output
        StringBuilder output = new StringBuilder();
        double total_price = 0.0;
        
        // Define your SQL query to retrieve the products
        String selectQuery = "SELECT product_id, product_name, price FROM cart";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(selectQuery);
             ResultSet resultSet = statement.executeQuery()) {

            // Start HTML output for the table
            output.append("<html><body><h1>Cart</h1><table border='1'><tr><th>Product ID</th><th>Product Name</th><th>Price</th></tr>");

            // Process the result set and append each product to the table
            while (resultSet.next()) {
                String productId = resultSet.getString("product_id");
                String productName = resultSet.getString("product_name");
                double price = resultSet.getDouble("price");
                total_price = total_price += price;

                output.append("<tr>")
                      .append("<td>").append(productId).append("</td>")
                      .append("<td>").append(productName).append("</td>")
                      .append("<td>").append(price).append("</td>")
                      .append("<td>").append(total_price).append("</td>")
                      .append("</tr>");
            }

            output.append("</table></body></html>");
            response.getWriter().println(output.toString());
            response.getWriter().println("<form action=\"cart.html\" method=\"POST\">\r\n"
            		+ "    <input type=\"submit\" value=\"Checkout\">");

        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Database error occurred: " + e.getMessage());
        }
    }
}
