package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.shopping_web.utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/AddtoCartServlet")
public class AddtoCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the product ID from the request
        int productId = Integer.parseInt(request.getParameter("productId"));
        HttpSession session = request.getSession();
        ArrayList<Integer> cart = (ArrayList<Integer>) session.getAttribute("cart");

        // Initialize the cart if it doesn't exist
        if (cart == null) {
            cart = new ArrayList<>();
        }

        // Add product to the cart session
        cart.add(productId);
        session.setAttribute("cart", cart);

        // Now, add the product to the database (cart table)
        try (Connection conn = DBConnection.getConnection()) {
            // Get product details from the products table
            String sql = "SELECT product_name, price FROM products WHERE product_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String productName = rs.getString("product_name");
                double productPrice = rs.getDouble("price");

                // Insert the product into the cart table
                String insertCartSql = "INSERT INTO cart (product_id, product_name, price) VALUES (?, ?, ?)";
                PreparedStatement insertStmt = conn.prepareStatement(insertCartSql);
                insertStmt.setInt(1, productId);  // product_id from the products table
                insertStmt.setString(2, productName);
                insertStmt.setDouble(3, productPrice);
               // insertStmt.setInt(4, 1);  // Default quantity as 1 (You can modify this)
              //  insertStmt.setString(5, session.getId());  // Use session ID to track user cart

                int rowInserted = insertStmt.executeUpdate();
                if (rowInserted > 0) {
                    response.getWriter().println("<h4>Product added to cart successfully!</h4>");
                } else {
                    response.getWriter().println("<h4>Error adding product to cart</h4>");
                }
            } else {
                response.getWriter().println("<h4>Product not found!</h4>");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("<h4>Database error: " + e.getMessage() + "</h4>");
        }
    }
}
